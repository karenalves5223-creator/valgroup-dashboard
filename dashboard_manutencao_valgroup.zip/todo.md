# Dashboard de Manutenção Valgroup - TODO

## Banco de Dados
- [x] Schema: tabela maintenance_records (data, maquina, tipoOrdem, tipoOperacao, horasReais, ano, mes)
- [x] Schema: tabela data_imports (histórico de importações)
- [x] Schema: tabela backups (registro de backups S3)
- [x] Migração do banco de dados

## Backend (tRPC)
- [x] Router de manutenção: list, stats, filtros, paginação
- [x] Router de importação: upload JSON/CSV, validação, inserção em lote
- [x] Router de exportação: gerar CSV para download
- [x] Router de backups: criar backup S3, listar backups, restaurar
- [x] Router de análise LLM: gerar insights, identificar padrões, sugestões

## Autenticação
- [x] Configurar Microsoft Azure AD OAuth
- [x] Integrar login Microsoft no frontend
- [x] Sistema de permissões: admin vs usuário
- [x] Proteção de rotas

## Dashboard Principal
- [x] Layout com sidebar usando DashboardLayout
- [x] KPIs em tempo real: total de horas, total de ordens, disponibilidade
- [x] Filtros: período, máquinas, tipo de ordem, tipo de operação
- [x] Gráfico: comparação mensal 2025 vs 2026
- [x] Gráfico: horas por categoria
- [x] Gráfico: top 5 máquinas

## Gestão de Dados
- [x] Tabela de dados detalhados com paginação
- [x] Exportação de dados para CSV
- [x] Upload de arquivo JSON para importação
- [x] Upload de arquivo CSV para importação
- [x] Histórico de importações

## Análises Inteligentes (LLM)
- [x] Análise automática de padrões de manutenção
- [x] Identificação de máquinas problemáticas
- [x] Sugestões de otimização
- [x] Relatório de insights gerado por IA

## Backups S3
- [x] Backup automático periódico
- [x] Listagem de backups disponíveis
- [x] Download/restauração de backup
- [x] Notificação de backup concluído

## Testes
- [x] Testes dos routers tRPC
- [x] Testes de importação de dados
- [x] Testes de autenticação

## Ajustes de Acesso e Identidade Visual
- [x] Upload da logo Valgroup para CDN
- [x] Inserir logo na sidebar, página de login e app title
- [x] Restringir acesso apenas a emails @VALGROUPCO.COM no backend
- [x] Exibir mensagem de erro clara para domínios não autorizados

## Ajustes de Login e Gráfico
- [x] Tela de login: substituir ícone pela logo Valgroup
- [x] Tela de login: corrigir @valgroup.com para @valgroupco.com
- [x] Tela de login: trocar rodapé por "Feito por Karen Alvez"
- [x] Tela de login: trocar "Sistema de Gestão de Manutenção" por "KPI - Visão Geral"
- [x] Gráfico comparação mensal: exibir apenas anos presentes nos dados filtrados

## Reaplicar Ajustes de Login (v2)
- [x] Logo Valgroup na tela de login
- [x] Subtítulo "KPI - Visão Geral"
- [x] Domínio @VALGROUPCO.COM
- [x] Rodapé "Feito por Karen Alvez"
- [x] Badge "Página Protegida" na tela de login

## Remover Login
- [x] Remover redirecionamento para /login no App.tsx e DashboardLayout
- [x] Converter todos os endpoints protectedProcedure para publicProcedure
- [x] Remover verificação de domínio @valgroupco.com do backend
- [x] Dashboard abre direto sem autenticação
