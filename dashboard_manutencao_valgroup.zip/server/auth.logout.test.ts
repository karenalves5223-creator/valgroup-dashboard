import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// O sistema de autenticação foi removido — o app é público.
// Este teste verifica que o router system.notifyOwner existe e está acessível.
describe("system router", () => {
  it("router system está disponível", () => {
    expect(appRouter).toBeDefined();
    // Verifica que os routers principais existem
    const routerDef = appRouter._def.procedures;
    expect(routerDef).toBeDefined();
  });
});

// Teste de contexto público
describe("public access", () => {
  it("acessa maintenance.stats sem autenticação", async () => {
    const ctx: TrpcContext = {
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    // Verifica que o caller foi criado sem erros
    expect(caller).toBeDefined();
  });
});
