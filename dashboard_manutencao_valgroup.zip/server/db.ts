import { and, asc, between, count, desc, eq, gte, inArray, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  DataBackup,
  DataImport,
  InsertDataBackup,
  InsertDataImport,
  InsertMaintenanceRecord,
  InsertUser,
  LlmAnalysis,
  MaintenanceRecord,
  dataBackups,
  dataImports,
  llmAnalyses,
  maintenanceRecords,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ───────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    const value = user[field];
    if (value !== undefined) {
      values[field] = value ?? null;
      updateSet[field] = value ?? null;
    }
  }

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }

  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Maintenance Records ──────────────────────────────────────────────────────

export interface MaintenanceFilters {
  maquinas?: string[];
  tiposOrdem?: string[];
  tiposOperacao?: string[];
  dataInicio?: string;
  dataFim?: string;
  page?: number;
  pageSize?: number;
}

export async function getMaintenanceRecords(filters: MaintenanceFilters = {}) {
  const db = await getDb();
  if (!db) return { records: [], total: 0 };

  const conditions = buildConditions(filters);
  const page = filters.page ?? 1;
  const pageSize = filters.pageSize ?? 50;
  const offset = (page - 1) * pageSize;

  const [records, totalResult] = await Promise.all([
    db
      .select()
      .from(maintenanceRecords)
      .where(conditions)
      .orderBy(desc(maintenanceRecords.data))
      .limit(pageSize)
      .offset(offset),
    db
      .select({ count: count() })
      .from(maintenanceRecords)
      .where(conditions),
  ]);

  return { records, total: totalResult[0]?.count ?? 0 };
}

export async function getAllMaintenanceRecordsForExport(filters: MaintenanceFilters = {}) {
  const db = await getDb();
  if (!db) return [];
  const conditions = buildConditions(filters);
  return db
    .select()
    .from(maintenanceRecords)
    .where(conditions)
    .orderBy(asc(maintenanceRecords.data));
}

function buildConditions(filters: MaintenanceFilters) {
  const conds = [];
  if (filters.maquinas && filters.maquinas.length > 0)
    conds.push(inArray(maintenanceRecords.maquina, filters.maquinas));
  if (filters.tiposOrdem && filters.tiposOrdem.length > 0)
    conds.push(inArray(maintenanceRecords.tipoOrdem, filters.tiposOrdem));
  if (filters.tiposOperacao && filters.tiposOperacao.length > 0)
    conds.push(inArray(maintenanceRecords.tipoOperacao, filters.tiposOperacao));
  if (filters.dataInicio) conds.push(gte(maintenanceRecords.data, filters.dataInicio));
  if (filters.dataFim) conds.push(lte(maintenanceRecords.data, filters.dataFim));
  return conds.length > 0 ? and(...conds) : undefined;
}

export async function getMaintenanceStats(filters: MaintenanceFilters = {}) {
  const db = await getDb();
  if (!db) return null;

  const conditions = buildConditions(filters);

  const [totals, byMonth, byCategory, byMachine] = await Promise.all([
    db
      .select({
        totalOrdens: count(),
        totalHoras: sql<number>`COALESCE(SUM(${maintenanceRecords.horasReais}), 0)`,
      })
      .from(maintenanceRecords)
      .where(conditions),
    db
      .select({
        ano: maintenanceRecords.ano,
        mes: maintenanceRecords.mes,
        totalHoras: sql<number>`COALESCE(SUM(${maintenanceRecords.horasReais}), 0)`,
        totalOrdens: count(),
      })
      .from(maintenanceRecords)
      .where(conditions)
      .groupBy(maintenanceRecords.ano, maintenanceRecords.mes)
      .orderBy(asc(maintenanceRecords.ano), asc(maintenanceRecords.mes)),
    db
      .select({
        tipoOrdem: maintenanceRecords.tipoOrdem,
        totalHoras: sql<number>`COALESCE(SUM(${maintenanceRecords.horasReais}), 0)`,
        totalOrdens: count(),
      })
      .from(maintenanceRecords)
      .where(conditions)
      .groupBy(maintenanceRecords.tipoOrdem)
      .orderBy(desc(sql`SUM(${maintenanceRecords.horasReais})`)),
    db
      .select({
        maquina: maintenanceRecords.maquina,
        totalHoras: sql<number>`COALESCE(SUM(${maintenanceRecords.horasReais}), 0)`,
        totalOrdens: count(),
      })
      .from(maintenanceRecords)
      .where(conditions)
      .groupBy(maintenanceRecords.maquina)
      .orderBy(desc(sql`SUM(${maintenanceRecords.horasReais})`))
      .limit(10),
  ]);

  return {
    totalOrdens: totals[0]?.totalOrdens ?? 0,
    totalHoras: totals[0]?.totalHoras ?? 0,
    byMonth,
    byCategory,
    byMachine,
  };
}

export async function getFilterOptions() {
  const db = await getDb();
  if (!db) return { maquinas: [], tiposOrdem: [], tiposOperacao: [] };

  const [maquinas, tiposOrdem, tiposOperacao] = await Promise.all([
    db
      .selectDistinct({ maquina: maintenanceRecords.maquina })
      .from(maintenanceRecords)
      .orderBy(asc(maintenanceRecords.maquina)),
    db
      .selectDistinct({ tipoOrdem: maintenanceRecords.tipoOrdem })
      .from(maintenanceRecords)
      .orderBy(asc(maintenanceRecords.tipoOrdem)),
    db
      .selectDistinct({ tipoOperacao: maintenanceRecords.tipoOperacao })
      .from(maintenanceRecords)
      .orderBy(asc(maintenanceRecords.tipoOperacao)),
  ]);

  return {
    maquinas: maquinas.map((r) => r.maquina),
    tiposOrdem: tiposOrdem.map((r) => r.tipoOrdem),
    tiposOperacao: tiposOperacao.map((r) => r.tipoOperacao),
  };
}

export async function insertMaintenanceRecordsBatch(
  records: InsertMaintenanceRecord[],
  batchSize = 500
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  let inserted = 0;
  for (let i = 0; i < records.length; i += batchSize) {
    const batch = records.slice(i, i + batchSize);
    await db.insert(maintenanceRecords).values(batch);
    inserted += batch.length;
  }
  return inserted;
}

export async function clearAllMaintenanceRecords() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(maintenanceRecords);
}

export async function countMaintenanceRecords() {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: count() }).from(maintenanceRecords);
  return result[0]?.count ?? 0;
}

// ─── Data Imports ─────────────────────────────────────────────────────────────

export async function createDataImport(data: InsertDataImport): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(dataImports).values(data);
  return Number((result[0] as any).insertId);
}

export async function updateDataImport(
  id: number,
  data: Partial<DataImport>
): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.update(dataImports).set(data).where(eq(dataImports.id, id));
}

export async function getDataImports(limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(dataImports)
    .orderBy(desc(dataImports.createdAt))
    .limit(limit);
}

// ─── Backups ──────────────────────────────────────────────────────────────────

export async function createBackupRecord(data: InsertDataBackup): Promise<number> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(dataBackups).values(data);
  return Number((result[0] as any).insertId);
}

export async function getBackups(limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(dataBackups)
    .orderBy(desc(dataBackups.createdAt))
    .limit(limit);
}

// ─── LLM Analyses ─────────────────────────────────────────────────────────────

export async function getLlmAnalysis(
  analysisType: string,
  filterHash: string
): Promise<LlmAnalysis | null> {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(llmAnalyses)
    .where(
      and(
        eq(llmAnalyses.analysisType, analysisType),
        eq(llmAnalyses.filterHash, filterHash)
      )
    )
    .orderBy(desc(llmAnalyses.createdAt))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function saveLlmAnalysis(
  analysisType: string,
  filterHash: string,
  content: string
): Promise<void> {
  const db = await getDb();
  if (!db) return;
  await db.insert(llmAnalyses).values({ analysisType, filterHash, content });
}
