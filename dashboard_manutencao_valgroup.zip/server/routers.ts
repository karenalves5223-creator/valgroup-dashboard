import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import {
  clearAllMaintenanceRecords,
  createBackupRecord,
  createDataImport,
  getAllMaintenanceRecordsForExport,
  getBackups,
  getDataImports,
  getFilterOptions,
  getLlmAnalysis,
  getMaintenanceRecords,
  getMaintenanceStats,
  insertMaintenanceRecordsBatch,
  saveLlmAnalysis,
  updateDataImport,
} from "./db";
import { storagePut, storageGet } from "./storage";
import { createHash } from "crypto";

const filtersSchema = z.object({
  maquinas: z.array(z.string()).optional(),
  tiposOrdem: z.array(z.string()).optional(),
  tiposOperacao: z.array(z.string()).optional(),
  dataInicio: z.string().optional(),
  dataFim: z.string().optional(),
});

// ─── Maintenance Router ───────────────────────────────────────────────────────

const maintenanceRouter = router({
  list: publicProcedure
    .input(
      filtersSchema.extend({
        page: z.number().min(1).default(1),
        pageSize: z.number().min(1).max(200).default(50),
      })
    )
    .query(async ({ input }) => {
      return getMaintenanceRecords(input);
    }),

  stats: publicProcedure
    .input(filtersSchema)
    .query(async ({ input }) => {
      return getMaintenanceStats(input);
    }),

  filterOptions: publicProcedure.query(async () => {
    return getFilterOptions();
  }),

  exportCsv: publicProcedure
    .input(filtersSchema)
    .mutation(async ({ input }) => {
      const records = await getAllMaintenanceRecordsForExport(input);
      const header = "data,maquina,tipoOrdem,tipoOperacao,horasReais,ano,mes\n";
      const rows = records
        .map(
          (r) =>
            `${r.data},"${r.maquina}","${r.tipoOrdem}","${r.tipoOperacao}",${r.horasReais},${r.ano},${r.mes}`
        )
        .join("\n");
      return { csv: header + rows, total: records.length };
    }),
});

// ─── Import Router ────────────────────────────────────────────────────────────

function parseDate(dateStr: string): { data: string; ano: number; mes: number } | null {
  if (!dateStr) return null;
  let d: Date | null = null;
  if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    d = new Date(dateStr + "T00:00:00");
  } else if (/^\d{2}\/\d{2}\/\d{4}$/.test(dateStr)) {
    const [day, month, year] = dateStr.split("/");
    d = new Date(`${year}-${month}-${day}T00:00:00`);
  }
  if (!d || isNaN(d.getTime())) return null;
  const ano = d.getFullYear();
  const mes = d.getMonth() + 1;
  const data = `${ano}-${String(mes).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
  return { data, ano, mes };
}

function parseJsonRecords(jsonData: any): any[] {
  if (Array.isArray(jsonData)) return jsonData;
  if (jsonData.records && Array.isArray(jsonData.records)) return jsonData.records;
  if (jsonData.data && Array.isArray(jsonData.data)) return jsonData.data;
  return [];
}

function parseCsvToRecords(csv: string): any[] {
  const lines = csv.trim().split("\n");
  if (lines.length < 2) return [];
  const headers = lines[0].split(",").map((h) => h.trim().replace(/"/g, "").toLowerCase());
  return lines.slice(1).map((line) => {
    const values = line.split(",").map((v) => v.trim().replace(/"/g, ""));
    const obj: Record<string, string> = {};
    headers.forEach((h, i) => { obj[h] = values[i] ?? ""; });
    return obj;
  });
}

function normalizeRecord(raw: any): any | null {
  const maquina = raw.maquina || raw.machine || raw.equipamento || raw.equipment || "";
  const tipoOrdem = raw.tipoOrdem || raw.tipo_ordem || raw.tiponome || raw.tipo_nome || raw.tipoNome || raw.order_type || "";
  const tipoOperacao = raw.tipoOperacao || raw.tipo_operacao || raw.tipo_de_ordem || raw.order_operation || raw.operacao || "";
  const horasRaw = raw.horasReais || raw.horas_reais || raw.horas || raw.hours || "0";
  const horasReais = parseFloat(String(horasRaw).replace(",", "."));
  const dateRaw = raw.data || raw.date || raw.dt || "";
  const parsed = parseDate(String(dateRaw));

  if (!parsed || !maquina || isNaN(horasReais)) return null;

  return {
    data: parsed.data,
    maquina: String(maquina).trim(),
    tipoOrdem: String(tipoOrdem || "Não especificado").trim(),
    tipoOperacao: String(tipoOperacao || "Não especificado").trim(),
    horasReais,
    ano: parsed.ano,
    mes: parsed.mes,
  };
}

const importRouter = router({
  uploadJson: publicProcedure
    .input(
      z.object({
        filename: z.string(),
        content: z.string(),
        replaceAll: z.boolean().default(false),
      })
    )
    .mutation(async ({ input }) => {
      let rawData: any;
      try {
        rawData = JSON.parse(input.content);
      } catch {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Arquivo JSON inválido." });
      }

      const rawRecords = parseJsonRecords(rawData);
      if (rawRecords.length === 0) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Nenhum registro encontrado no arquivo JSON." });
      }

      const importId = await createDataImport({
        filename: input.filename,
        fileType: "json",
        totalRecords: rawRecords.length,
        insertedRecords: 0,
        status: "processing",
        importedBy: null,
      });

      try {
        const records = rawRecords
          .map((r) => normalizeRecord(r))
          .filter(Boolean)
          .map((r) => ({ ...r, importId }));

        if (input.replaceAll) await clearAllMaintenanceRecords();

        const inserted = await insertMaintenanceRecordsBatch(records);
        await updateDataImport(importId, {
          status: "success",
          insertedRecords: inserted,
          completedAt: new Date(),
        });

        return { success: true, inserted, total: rawRecords.length, importId };
      } catch (err) {
        await updateDataImport(importId, {
          status: "error",
          errorMessage: String(err),
          completedAt: new Date(),
        });
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Erro ao processar importação." });
      }
    }),

  uploadCsv: publicProcedure
    .input(
      z.object({
        filename: z.string(),
        content: z.string(),
        replaceAll: z.boolean().default(false),
      })
    )
    .mutation(async ({ input }) => {
      const rawRecords = parseCsvToRecords(input.content);
      if (rawRecords.length === 0) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Nenhum registro encontrado no arquivo CSV." });
      }

      const importId = await createDataImport({
        filename: input.filename,
        fileType: "csv",
        totalRecords: rawRecords.length,
        insertedRecords: 0,
        status: "processing",
        importedBy: null,
      });

      try {
        const records = rawRecords
          .map((r) => normalizeRecord(r))
          .filter(Boolean)
          .map((r) => ({ ...r, importId }));

        if (input.replaceAll) await clearAllMaintenanceRecords();

        const inserted = await insertMaintenanceRecordsBatch(records);
        await updateDataImport(importId, {
          status: "success",
          insertedRecords: inserted,
          completedAt: new Date(),
        });

        return { success: true, inserted, total: rawRecords.length, importId };
      } catch (err) {
        await updateDataImport(importId, {
          status: "error",
          errorMessage: String(err),
          completedAt: new Date(),
        });
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Erro ao processar importação CSV." });
      }
    }),

  history: publicProcedure.query(async () => {
    return getDataImports(20);
  }),
});

// ─── Backup Router ────────────────────────────────────────────────────────────

const backupRouter = router({
  create: publicProcedure.mutation(async () => {
    const records = await getAllMaintenanceRecordsForExport({});
    const total = records.length;

    const backupData = JSON.stringify({ records, exportedAt: new Date().toISOString(), total });
    const buffer = Buffer.from(backupData, "utf-8");
    const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
    const key = `backups/maintenance-${timestamp}.json`;

    const { url } = await storagePut(key, buffer, "application/json");

    const id = await createBackupRecord({
      s3Key: key,
      s3Url: url,
      sizeBytes: buffer.length,
      totalRecords: total,
      backupType: "manual",
      createdBy: null,
    });

    return { success: true, id, url, total, sizeBytes: buffer.length };
  }),

  list: publicProcedure.query(async () => {
    return getBackups(20);
  }),

  getDownloadUrl: publicProcedure
    .input(z.object({ s3Key: z.string() }))
    .query(async ({ input }) => {
      const { url } = await storageGet(input.s3Key);
      return { url };
    }),
});

// ─── Analysis Router (LLM) ───────────────────────────────────────────────────

const analysisRouter = router({
  generate: publicProcedure
    .input(
      z.object({
        analysisType: z.enum(["overview", "machines", "trends", "optimization"]),
        filters: filtersSchema.optional(),
        forceRefresh: z.boolean().default(false),
      })
    )
    .mutation(async ({ input }) => {
      const filterHash = createHash("md5")
        .update(JSON.stringify(input.filters ?? {}))
        .digest("hex")
        .slice(0, 16);

      if (!input.forceRefresh) {
        const cached = await getLlmAnalysis(input.analysisType, filterHash);
        if (cached) {
          const ageMs = Date.now() - new Date(cached.createdAt).getTime();
          if (ageMs < 3600000) {
            return { content: cached.content, cached: true };
          }
        }
      }

      const [stats, filterOptions] = await Promise.all([
        getMaintenanceStats(input.filters ?? {}),
        getFilterOptions(),
      ]);

      if (!stats) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Sem dados para análise." });

      const topMachines = stats.byMachine.slice(0, 5);
      const topCategories = stats.byCategory.slice(0, 5);

      const prompts: Record<string, string> = {
        overview: `Você é um especialista em manutenção industrial. Analise os seguintes dados de manutenção da Valgroup e forneça um resumo executivo em português:

**Dados Gerais:**
- Total de ordens: ${stats.totalOrdens}
- Total de horas: ${stats.totalHoras.toFixed(2)}h
- Máquinas monitoradas: ${filterOptions.maquinas.length}

**Top 5 Máquinas por Horas:**
${topMachines.map((m) => `- ${m.maquina}: ${Number(m.totalHoras).toFixed(2)}h (${m.totalOrdens} ordens)`).join("\n")}

**Distribuição por Categoria:**
${topCategories.map((c) => `- ${c.tipoOrdem}: ${Number(c.totalHoras).toFixed(2)}h`).join("\n")}

Forneça: 1) Resumo executivo (2-3 parágrafos), 2) Principais observações (3-5 pontos), 3) Indicadores de performance. Seja objetivo e use linguagem técnica adequada.`,

        machines: `Você é um especialista em manutenção industrial. Analise o desempenho das máquinas da Valgroup:

**Ranking de Máquinas por Horas de Manutenção:**
${stats.byMachine.map((m, i) => `${i + 1}. ${m.maquina}: ${Number(m.totalHoras).toFixed(2)}h (${m.totalOrdens} ordens)`).join("\n")}

Identifique: 1) Máquinas críticas que precisam de atenção, 2) Padrões de falha, 3) Máquinas com melhor e pior desempenho, 4) Recomendações específicas por máquina. Use linguagem técnica em português.`,

        trends: `Você é um especialista em análise de dados de manutenção. Analise as tendências temporais:

**Dados Mensais (Ano/Mês: Horas/Ordens):**
${stats.byMonth.map((m) => `${m.ano}/${String(m.mes).padStart(2, "0")}: ${Number(m.totalHoras).toFixed(2)}h, ${m.totalOrdens} ordens`).join("\n")}

Identifique: 1) Tendências de crescimento ou redução, 2) Sazonalidade, 3) Meses críticos, 4) Comparação 2025 vs 2026, 5) Previsões para próximos meses. Use linguagem técnica em português.`,

        optimization: `Você é um especialista em otimização de manutenção industrial. Com base nos dados da Valgroup:

**Categorias de Manutenção:**
${topCategories.map((c) => `- ${c.tipoOrdem}: ${Number(c.totalHoras).toFixed(2)}h (${c.totalOrdens} ordens)`).join("\n")}

**Máquinas Críticas:**
${topMachines.map((m) => `- ${m.maquina}: ${Number(m.totalHoras).toFixed(2)}h`).join("\n")}

Sugira: 1) Estratégias de manutenção preventiva, 2) Oportunidades de redução de custos, 3) Priorização de recursos, 4) Indicadores KPI recomendados, 5) Plano de ação de 90 dias. Use linguagem técnica em português.`,
      };

      const response = await invokeLLM({
        messages: [
          { role: "system" as const, content: "Você é um especialista em manutenção industrial e análise de dados. Responda sempre em português brasileiro, de forma clara, objetiva e profissional. Use formatação markdown." },
          { role: "user" as const, content: prompts[input.analysisType] },
        ],
      });

      const rawContent = response.choices?.[0]?.message?.content;
      const content = typeof rawContent === "string" ? rawContent : "Análise não disponível.";
      await saveLlmAnalysis(input.analysisType, filterHash, content);

      return { content, cached: false };
    }),
});

// ─── App Router ───────────────────────────────────────────────────────────────

export const appRouter = router({
  system: systemRouter,
  maintenance: maintenanceRouter,
  import: importRouter,
  backup: backupRouter,
  analysis: analysisRouter,
});

export type AppRouter = typeof appRouter;
