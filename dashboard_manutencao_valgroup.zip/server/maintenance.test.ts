import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock do banco de dados
vi.mock("./db", () => ({
  getMaintenanceRecords: vi.fn().mockResolvedValue({ records: [], total: 0 }),
  getMaintenanceStats: vi.fn().mockResolvedValue({
    totalOrdens: 100,
    totalHoras: 500.5,
    byMonth: [],
    byCategory: [],
    byMachine: [],
  }),
  getFilterOptions: vi.fn().mockResolvedValue({
    maquinas: ["P401-PRD-ESH-1001", "P401-PRD-ESH-1002"],
    tiposOrdem: ["Manutenção Preventiva", "Manutenção Corretiva"],
    tiposOperacao: ["Mecânica", "Elétrica"],
  }),
  getAllMaintenanceRecordsForExport: vi.fn().mockResolvedValue([
    {
      id: 1,
      data: "2025-01-15",
      maquina: "P401-PRD-ESH-1001",
      tipoOrdem: "Manutenção Preventiva",
      tipoOperacao: "Mecânica",
      horasReais: 4.5,
      ano: 2025,
      mes: 1,
    },
  ]),
  insertMaintenanceRecordsBatch: vi.fn().mockResolvedValue(10),
  clearAllMaintenanceRecords: vi.fn().mockResolvedValue(undefined),
  countMaintenanceRecords: vi.fn().mockResolvedValue(100),
  createDataImport: vi.fn().mockResolvedValue(1),
  updateDataImport: vi.fn().mockResolvedValue(undefined),
  getDataImports: vi.fn().mockResolvedValue([]),
  createBackupRecord: vi.fn().mockResolvedValue(1),
  getBackups: vi.fn().mockResolvedValue([]),
  getLlmAnalysis: vi.fn().mockResolvedValue(null),
  saveLlmAnalysis: vi.fn().mockResolvedValue(undefined),
}));

vi.mock("./storage", () => ({
  storagePut: vi.fn().mockResolvedValue({ key: "test-key", url: "https://example.com/test.json" }),
  storageGet: vi.fn().mockResolvedValue({ key: "test-key", url: "https://example.com/test.json" }),
}));

vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [{ message: { content: "Análise de teste gerada pela IA." } }],
  }),
}));

// Sem autenticação: contexto público
function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("maintenance.stats", () => {
  it("retorna estatísticas sem autenticação", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.maintenance.stats({});
    expect(result).toBeDefined();
    expect(result?.totalOrdens).toBe(100);
    expect(result?.totalHoras).toBe(500.5);
  });
});

describe("maintenance.filterOptions", () => {
  it("retorna opções de filtro sem autenticação", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.maintenance.filterOptions();
    expect(result.maquinas).toHaveLength(2);
    expect(result.tiposOrdem).toHaveLength(2);
    expect(result.tiposOperacao).toHaveLength(2);
  });
});

describe("maintenance.list", () => {
  it("retorna lista paginada sem autenticação", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.maintenance.list({ page: 1, pageSize: 10 });
    expect(result).toBeDefined();
    expect(Array.isArray(result.records)).toBe(true);
    expect(typeof result.total).toBe("number");
  });
});

describe("maintenance.exportCsv", () => {
  it("gera CSV com cabeçalho correto sem autenticação", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.maintenance.exportCsv({});
    expect(result.csv).toContain("data,maquina,tipoOrdem,tipoOperacao,horasReais,ano,mes");
    expect(result.total).toBe(1);
  });
});

describe("import.uploadJson", () => {
  it("aceita JSON válido sem autenticação", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const records = [
      {
        data: "2025-01-15",
        maquina: "P401-PRD-ESH-1001",
        tipoOrdem: "Manutenção Preventiva",
        tipoOperacao: "Mecânica",
        horasReais: 4.5,
      },
    ];
    const result = await caller.import.uploadJson({
      filename: "test.json",
      content: JSON.stringify({ records }),
      replaceAll: false,
    });
    expect(result.success).toBe(true);
  });

  it("rejeita JSON inválido", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.import.uploadJson({
        filename: "test.json",
        content: "invalid json {{{",
        replaceAll: false,
      })
    ).rejects.toThrow("Arquivo JSON inválido.");
  });

  it("rejeita JSON sem registros", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.import.uploadJson({
        filename: "test.json",
        content: JSON.stringify({ records: [] }),
        replaceAll: false,
      })
    ).rejects.toThrow("Nenhum registro encontrado");
  });
});

describe("backup.create", () => {
  it("cria backup sem autenticação", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.backup.create();
    expect(result.success).toBe(true);
    expect(result.url).toBe("https://example.com/test.json");
  });
});

describe("backup.list", () => {
  it("retorna lista de backups sem autenticação", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.backup.list();
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("import.history", () => {
  it("retorna histórico de importações sem autenticação", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.import.history();
    expect(Array.isArray(result)).toBe(true);
  });
});
