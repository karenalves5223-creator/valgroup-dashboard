CREATE TABLE `data_backups` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`s3Key` varchar(500) NOT NULL,
	`s3Url` text NOT NULL,
	`sizeBytes` bigint NOT NULL DEFAULT 0,
	`totalRecords` int NOT NULL DEFAULT 0,
	`backupType` enum('manual','automatic') NOT NULL DEFAULT 'manual',
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `data_backups_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `data_imports` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`filename` varchar(255) NOT NULL,
	`fileType` enum('json','csv') NOT NULL,
	`totalRecords` int NOT NULL DEFAULT 0,
	`insertedRecords` int NOT NULL DEFAULT 0,
	`status` enum('pending','processing','success','error') NOT NULL DEFAULT 'pending',
	`errorMessage` text,
	`importedBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `data_imports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `llm_analyses` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`analysisType` varchar(50) NOT NULL,
	`filterHash` varchar(64) NOT NULL,
	`content` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `llm_analyses_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `maintenance_records` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`data` varchar(10) NOT NULL,
	`maquina` varchar(100) NOT NULL,
	`tipoOrdem` varchar(100) NOT NULL,
	`tipoOperacao` varchar(100) NOT NULL,
	`horasReais` float NOT NULL,
	`ano` int NOT NULL,
	`mes` int NOT NULL,
	`importId` bigint,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `maintenance_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `idx_data` ON `maintenance_records` (`data`);--> statement-breakpoint
CREATE INDEX `idx_maquina` ON `maintenance_records` (`maquina`);--> statement-breakpoint
CREATE INDEX `idx_ano_mes` ON `maintenance_records` (`ano`,`mes`);--> statement-breakpoint
CREATE INDEX `idx_tipoOrdem` ON `maintenance_records` (`tipoOrdem`);--> statement-breakpoint
CREATE INDEX `idx_tipoOperacao` ON `maintenance_records` (`tipoOperacao`);