import {
  bigint,
  decimal,
  float,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Tabela principal de registros de manutenção
export const maintenanceRecords = mysqlTable(
  "maintenance_records",
  {
    id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
    data: varchar("data", { length: 10 }).notNull(), // YYYY-MM-DD
    maquina: varchar("maquina", { length: 100 }).notNull(),
    tipoOrdem: varchar("tipoOrdem", { length: 100 }).notNull(),
    tipoOperacao: varchar("tipoOperacao", { length: 100 }).notNull(),
    horasReais: float("horasReais").notNull(),
    ano: int("ano").notNull(),
    mes: int("mes").notNull(),
    importId: bigint("importId", { mode: "number" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("idx_data").on(table.data),
    index("idx_maquina").on(table.maquina),
    index("idx_ano_mes").on(table.ano, table.mes),
    index("idx_tipoOrdem").on(table.tipoOrdem),
    index("idx_tipoOperacao").on(table.tipoOperacao),
  ]
);

export type MaintenanceRecord = typeof maintenanceRecords.$inferSelect;
export type InsertMaintenanceRecord = typeof maintenanceRecords.$inferInsert;

// Histórico de importações de dados
export const dataImports = mysqlTable("data_imports", {
  id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
  filename: varchar("filename", { length: 255 }).notNull(),
  fileType: mysqlEnum("fileType", ["json", "csv"]).notNull(),
  totalRecords: int("totalRecords").notNull().default(0),
  insertedRecords: int("insertedRecords").notNull().default(0),
  status: mysqlEnum("status", ["pending", "processing", "success", "error"])
    .notNull()
    .default("pending"),
  errorMessage: text("errorMessage"),
  importedBy: int("importedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
});

export type DataImport = typeof dataImports.$inferSelect;
export type InsertDataImport = typeof dataImports.$inferInsert;

// Registro de backups S3
export const dataBackups = mysqlTable("data_backups", {
  id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
  s3Key: varchar("s3Key", { length: 500 }).notNull(),
  s3Url: text("s3Url").notNull(),
  sizeBytes: bigint("sizeBytes", { mode: "number" }).notNull().default(0),
  totalRecords: int("totalRecords").notNull().default(0),
  backupType: mysqlEnum("backupType", ["manual", "automatic"])
    .notNull()
    .default("manual"),
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type DataBackup = typeof dataBackups.$inferSelect;
export type InsertDataBackup = typeof dataBackups.$inferInsert;

// Cache de análises LLM
export const llmAnalyses = mysqlTable("llm_analyses", {
  id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
  analysisType: varchar("analysisType", { length: 50 }).notNull(),
  filterHash: varchar("filterHash", { length: 64 }).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type LlmAnalysis = typeof llmAnalyses.$inferSelect;
