import { drizzle } from "drizzle-orm/mysql2";
import { createConnection } from "mysql2/promise";
import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import dotenv from "dotenv";

const __dirname = dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: join(__dirname, "../.env") });

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL não encontrada");
  process.exit(1);
}

const dataPath = "/home/ubuntu/dashboard_data.json";
const rawData = JSON.parse(readFileSync(dataPath, "utf-8"));
const records = rawData.records;

console.log(`📊 Total de registros a importar: ${records.length}`);

const connection = await createConnection(DATABASE_URL);
const db = drizzle(connection);

// Limpar registros existentes
await connection.execute("DELETE FROM maintenance_records");
console.log("🗑️  Registros existentes removidos");

// Inserir em lotes de 500
const batchSize = 500;
let inserted = 0;

for (let i = 0; i < records.length; i += batchSize) {
  const batch = records.slice(i, i + batchSize);
  const values = batch.map((r) => {
    const dateStr = String(r.data || "");
    let data = dateStr;
    let ano = r.ano;
    let mes = r.mes;

    if (!ano || !mes) {
      const d = new Date(dateStr + "T00:00:00");
      ano = d.getFullYear();
      mes = d.getMonth() + 1;
    }

    return [
      data,
      String(r.maquina || "").trim(),
      String(r.tipoOrdem || "Não especificado").trim(),
      String(r.tipoOperacao || "Não especificado").trim(),
      parseFloat(String(r.horasReais || "0").replace(",", ".")),
      ano,
      mes,
      null, // importId
    ];
  });

  const placeholders = values.map(() => "(?, ?, ?, ?, ?, ?, ?, ?)").join(", ");
  const flatValues = values.flat();

  await connection.execute(
    `INSERT INTO maintenance_records (data, maquina, tipoOrdem, tipoOperacao, horasReais, ano, mes, importId) VALUES ${placeholders}`,
    flatValues
  );

  inserted += batch.length;
  process.stdout.write(`\r✅ Inseridos: ${inserted}/${records.length}`);
}

console.log(`\n🎉 Importação concluída! ${inserted} registros inseridos.`);
await connection.end();
